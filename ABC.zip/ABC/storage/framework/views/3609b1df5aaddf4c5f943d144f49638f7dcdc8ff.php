<?php $__env->startSection('title', 'register'); ?>
<?php $__env->startSection('content'); ?>


	<div class="card shadow mb-4">
	  	<?php if(Session::has('successmsg')): ?>
		<div class="alert alert-success alert-dismissible fade show" role="alert">
		  <strong><?php echo e(Session::get("successmsg")); ?></strong> 
		  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
			<span aria-hidden="true">&times;</span>
		  </button>
		</div>
		<?php endif; ?>
		<!--ERROR-->
		<?php if(count($errors) > 0): ?>
			<div class="alert alert-danger alert-dismissible" role="alert">
			   <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				 <ul>
				   <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					   <li><?php echo e($error); ?></li>
				   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				 </ul>
			 </div>
		<?php endif; ?>
		<!--/ERROR-->
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Employee</h6>
            </div>
            <div class="card-body">
              <form class="user" action="/register" method="post">
			   <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"/>
                <div class="form-group">
                  <input type="text" name="employeeName" value="<?php echo e(old('employeeName')); ?>" class="form-control form-control-user"  placeholder="Name">
                </div>
                <div class="form-group">
                  <input type="text" name="employeeAddress" value="<?php echo e(old('employeeAddress')); ?>" class="form-control form-control-user" placeholder="Address">
                </div>
                <div class="form-group row">
                  <div class="col-sm-6 mb-3 mb-sm-0">
                    <input type="text" name="employeePhone" value="<?php echo e(old('employeePhone')); ?>" class="form-control form-control-user"  placeholder="Phone">
                  </div>
				  
                  <div class="col-sm-6">
					<select class="form-control" name="employeeCityId">
						<option value="">Select City</option>
						<?php $__currentLoopData = $city; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($row->cityId); ?>"><?php echo e($row->cityName); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>  
                  </div>
                </div>
				<div class="form-group row">
                  <div class="col-sm-6 mb-3 mb-sm-0">
                    <input type="email" name="employeeEmail" value="<?php echo e(old('employeeEmail')); ?>" class="form-control form-control-user"  placeholder="Email">
                  </div>
                  <div class="col-sm-6">
                    <select class="form-control" name="employeePrivilegeId">
						<option value="">Select Privilege</option>
						<?php $__currentLoopData = $privilege; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($row->privilegeId); ?>"><?php echo e($row->privilege); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select> 
                  </div>
                </div>
				<div class="form-group row">
                  <div class="col-sm-6 mb-3 mb-sm-0">
                    <input type="password" name="password" class="form-control form-control-user"  placeholder="Password">
                  </div>
                  <div class="col-sm-6">
                    <input type="password"  name="repeatpassword" class="form-control form-control-user"  placeholder="Repeat Password">
                  </div>
                </div>
                <input type="submit" class="btn btn-primary btn-user btn-block" value="Register Account">
                  
              </form>
			 </div> <!--card-body-->
	</div><!--card-->
			  
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>