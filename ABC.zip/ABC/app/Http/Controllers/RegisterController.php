<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\City;
use App\Privilege;
use App\Employee;
use Validator;
use Hash;


class RegisterController extends Controller
{
    public function index(){
	
	 $city = new City();
	 $city=$city->citySelect();
	 
	 $privilege = new Privilege();
	 $privilege=$privilege->privilegeSelect();
	 
	 return view('register-employee', [
									 'city' => $city,
									 'privilege' => $privilege,
									 ]);
	}
	
	
public function save(Request $request){
	 //return $request;
		$inputs = $request->all();

        $rules = array(
            'employeeName' => 'required|max:20',
            'employeeAddress' => 'required|max:45',
            'employeePhone' => 'max:20|regex:/^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/',
            'employeeCityId' => 'required|exists:city,cityId',
			'employeePrivilegeId' => 'required|exists:privilege,privilegeId',
			'employeeEmail' => 'required|email|unique:Employee,username',
            'password' => 'required|min:6|max:20',
        );

	$validation = Validator::make($inputs, $rules);

	if($validation->fails()){
     return redirect()->back()
                 ->withErrors($validation)
                 ->withInput();
	  }else{ 
		 //if data is validated,type the code to insert data and retunn to the target page.   
		 
         //Generating password and hashes

        $password = $request->input('password');

        $passwordStaticSalt= "anyWord@134";

        $hashedPassword = Hash::make($password.$passwordStaticSalt);

			if(Hash::check($password.$passwordStaticSalt, $hashedPassword)){
				
				/*
				inserring employee with hashed password
				*/
				$employee = new Employee;
				$employee->fill($request->all());
				$employee->password = $hashedPassword;
			   // $user->passwordSalt = $passwordSalt;
			   // $user->ipAddress = preg_replace('#[^0-9.]#', '', getenv('REMOTE_ADDR'));
			   // $user->activation = 0;
				$employee->username = $request->employeeEmail;
				$employee->save();
			
			 $msg="Success";
			 return redirect()->back()->with('successmsg', $msg);
			}
		}
	 
	}

}	