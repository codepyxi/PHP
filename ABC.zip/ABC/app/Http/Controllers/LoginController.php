<?php

namespace App\Http\Controllers;

use Hash;
use Auth;

class RegisterController extends Controller
{
//user login	
	public function userLogin(Request $request){
		$username = $request->username;
		$password = $request->password;
		$passwordStaticSalt="NoMore!@!MVS";

		$user = User::select()
						->where('username','=',$username)
						->where('userActif','=',1)
						->get();
						
						
							
		if($user->count() == 1){
			if (Hash::check($password.$passwordStaticSalt, $user[0]->password)){
				if (Auth::attempt(['userId'=>$user[0]->userId, 'password'=>$password.$passwordStaticSalt],TRUE)){
date_default_timezone_set('America/Toronto');
$logIn = date('Y-m-d H:i:s');					

				
					$newLog = new LogAccess();
					$newLog->logUserId = $user[0]->userId;
					$newLog->logIn = $logIn;
					$newLog->save();		
					return redirect('/my-courses');	
				}else{
					return redirect('login');
				}
			}else{
			return view('../login', ['errorLogin' => 'Please check your password !']);
						
			}
		}else{
			return view('../login', ['errorLogin' => 'Please check your username !']);
					
		}
	}
}	