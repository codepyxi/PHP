@extends('master')
@section('title', 'register')
@section('content')


	<div class="card shadow mb-4">
	  	@if(Session::has('successmsg'))
		<div class="alert alert-success alert-dismissible fade show" role="alert">
		  <strong>{{Session::get("successmsg")}}</strong> 
		  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
			<span aria-hidden="true">&times;</span>
		  </button>
		</div>
		@endif
		<!--ERROR-->
		@if (count($errors) > 0)
			<div class="alert alert-danger alert-dismissible" role="alert">
			   <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				 <ul>
				   @foreach ($errors->all() as $error)
					   <li>{{ $error }}</li>
				   @endforeach
				 </ul>
			 </div>
		@endif
		<!--/ERROR-->
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Employee</h6>
            </div>
            <div class="card-body">
              <form class="user" action="/register" method="post">
			   <input type="hidden" name="_token" value="{{csrf_token()}}"/>
                <div class="form-group">
                  <input type="text" name="employeeName" value="{{old('employeeName')}}" class="form-control form-control-user"  placeholder="Name">
                </div>
                <div class="form-group">
                  <input type="text" name="employeeAddress" value="{{old('employeeAddress')}}" class="form-control form-control-user" placeholder="Address">
                </div>
                <div class="form-group row">
                  <div class="col-sm-6 mb-3 mb-sm-0">
                    <input type="text" name="employeePhone" value="{{old('employeePhone')}}" class="form-control form-control-user"  placeholder="Phone">
                  </div>
				  
                  <div class="col-sm-6">
					<select class="form-control" name="employeeCityId">
						<option value="">Select City</option>
						@foreach($city as $row)
						<option value="{{$row->cityId}}">{{$row->cityName}}</option>
						@endforeach
					</select>  
                  </div>
                </div>
				<div class="form-group row">
                  <div class="col-sm-6 mb-3 mb-sm-0">
                    <input type="email" name="employeeEmail" value="{{old('employeeEmail')}}" class="form-control form-control-user"  placeholder="Email">
                  </div>
                  <div class="col-sm-6">
                    <select class="form-control" name="employeePrivilegeId">
						<option value="">Select Privilege</option>
						@foreach($privilege as $row)
						<option value="{{$row->privilegeId}}">{{$row->privilege}}</option>
						@endforeach
					</select> 
                  </div>
                </div>
				<div class="form-group row">
                  <div class="col-sm-6 mb-3 mb-sm-0">
                    <input type="password" name="password" class="form-control form-control-user"  placeholder="Password">
                  </div>
                  <div class="col-sm-6">
                    <input type="password"  name="repeatpassword" class="form-control form-control-user"  placeholder="Repeat Password">
                  </div>
                </div>
                <input type="submit" class="btn btn-primary btn-user btn-block" value="Register Account">
                  
              </form>
			 </div> <!--card-body-->
	</div><!--card-->
			  
@endsection 